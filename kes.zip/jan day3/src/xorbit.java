

import java.util.*;

public class xorbit {
    public static void main(String[]args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int tot=0;
        int[] mat = new int[n+n+2];
        for (int i = 0; i < n+n+2; i++) {
            mat[i] = sc.nextInt();
            tot^=mat[i];
        }
        int count=0;
        while(((tot>>count)&1)==0)count++;
        int zo=0,eo=0;
        for(int num:mat){
            if(((num>>count)&1)==1){
                eo^=num;
            }else{
                zo^=num;
            }

        }
        System.out.print(zo+" "+eo);






    }
}


