import java.awt.desktop.SystemSleepEvent;
import java.util.*;

public class xoras {
    public static void main(String[]args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] mat = new int[n];
        for (int i = 0; i < n ; i++) {
            mat[i] = sc.nextInt();
        }
        HashMap<Integer,Integer> map=new HashMap<>();
      for(int num:mat){
          map.put(num,map.getOrDefault(num,0)+1);
      }
      for(int num:mat){
          if(map.get(num)==1){
              System.out.print(num+" ");
          }
      }

    }
}
