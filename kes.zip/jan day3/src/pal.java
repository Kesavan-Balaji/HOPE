import java.util.*;
public class pal {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String[]words=new String[n];
        for(int i=0;i<n;i++){
            words[i]=sc.nextLine();
        }
        int count=0;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(find(words[i],words[j]))count++;
            }
        }
        System.out.print(count);
    }
    static boolean find(String s,String d){
        int tot = 0;
        String st=s+d;
        for (char ch : st.toCharArray()) {
            tot ^= (1<< (ch - 'a'));
        }
        return ((tot == 0 || ((tot & (tot - 1)) == 0)));
    }
}
