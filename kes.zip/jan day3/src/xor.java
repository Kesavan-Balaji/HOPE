import java.util.Scanner;

public class xor {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[]mat=new int[n+n+1];
        for(int i=0;i<n+n+1;i++){
            mat[i]=sc.nextInt();
        }
        int tot=0;
        for(int num:mat){
            tot=tot^num;
        }
        System.out.print(tot);
    }
}
